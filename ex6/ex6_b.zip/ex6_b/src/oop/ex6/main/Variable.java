package oop.ex6.main;

import static oop.ex6.AllHelpingVariables.*;

/**
 * Variable's Class represents on each variable, it is mean each variable in the file has a object
 * from this class and this class has the characters of the method.
 */
public class Variable {
    // represents the type, name of the variable
    private String type,varName;
    // represents the value of this variable
    private Object varValue;
    // represents to the situation of it is final or not
    private boolean isFinal;
    //todo
    private boolean isInit,isParam;

    /**
     * This constructor method
     * @param type - type of this variable
     * @param varName - name of this variable
     * @param varValue - value of this variable
     * @param isFinal - the situation of this variable is final or not
     * @param isParam todo
     * @param isInit - the situation of this variable is initializes or not
     * @throws IllegalFormationException - Exception if wrong value or type
     */
    public Variable(String type, String varName, Object varValue, boolean isFinal,boolean isParam,
                    boolean isInit) throws IllegalFormationException{
        if (type.matches(TYPES))
            this.type=type;
        else throw new IllegalFormationException(TYPE_MSG);
        if (varName.matches(VARIABLE_NAME) && !KEYWORDS.contains(varName))
            this.varName=varName;
        else throw new IllegalFormationException(VALUE_MSG);
        this.isInit=isInit;
        this.isParam=isParam;
        this.varValue=varValue;
        this.isFinal=isFinal;
    }

    /**
     * @return - true if the variable is initializes, otherwise false
     */
    public boolean getIsInit(){return this.isInit;}
    /**
     * @return - the type of this variable
     */
    public String getType() {
        return type;
    }
    /**
     * @return - the name of this variable
     */
    public String getVarName() {
        return varName;
    }

    /**
     * todo
     */
    public void setVarValue(Object varValue) {
        this.varValue = varValue;
    }

    /**
     * @return - the value of this variable
     */
    public Object getVarValue() {
        return varValue;
    }

//    public void setIsFinal(boolean isFinal) {
//        this.isFinal = isFinal;
//    }

    /**
     * @return - true if the variable final, otherwise false
     */
    public boolean getIsFinal() {
        return isFinal;
    }


//    public boolean equals(Variable variable){
//        if (!variable.varName.equals(this.varName)) return false;
//        if (!variable.type.equals(this.type)) return false;
//        if (!variable.isParam==this.isParam) return false;
//        if (!variable.isInit==this.isInit) return false;
//        if (!variable.isFinal==this.isFinal) return false;
//        if (!(variable.varValue==this.varValue))return false;
//        if (!variable.varValue.equals(this.varValue)) return false;
//        return true;
//    }
//    @Override
//    public int compareTo(Variable variable) {
//        if (variable.getVarName().equals(varName))
//        return 0;
//    }

}
