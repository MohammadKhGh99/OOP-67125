package oop.ex6.main;

/**
 * This Class is Exception class extend from the Exception's class
 */
public class FatherException extends Exception {
    // constructor that receive a message
    public FatherException(String message){
        super(message);
    }
}
