package oop.ex6.main;

import java.util.*;

/**
 * todo
 */
public abstract class Line {

    protected LinkedList<Variable> variables;
    protected LinkedList<Method> methods;


    public Line(){
        this.variables=new LinkedList<>();
    }

    public Line(LinkedList<Variable> variables, LinkedList<Method> methods){
        this.variables=variables;
        this.methods=methods;
    }

    /**
     * this method reads the line and extracts the wanted Strings from it.
     * @param line the required line to read.
     * @return LinkedList that contains the wanted items from this line.
     * @throws IllegalFormationException if there is a problem with values or types or anything else.
     */
    public abstract LinkedList<? extends Object> parsingLine(String line) throws IllegalFormationException;
}
