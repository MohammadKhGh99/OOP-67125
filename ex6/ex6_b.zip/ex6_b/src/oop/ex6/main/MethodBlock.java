package oop.ex6.main;

import java.util.LinkedList;
import static oop.ex6.AllHelpingVariables.*;

/**
 *  This class describe the Method block extends Block class, parsing the method block...
 */
public class MethodBlock extends Block{

    /**
     * the constructor of method block, calling the constructor of Block class.
     * @param globalVariables the global variables for this block.
     */
    public MethodBlock(LinkedList<Variable> globalVariables) {
        super(globalVariables);
    }

    /**
     * this method parses MethodBlock, check if it is legal.
     * @param blockLines the lines for this block.
     * @throws IllegalFormationException if there is an error in parsing the block.
     */
    @Override
    public void parsingBlock(LinkedList<String> blockLines) throws IllegalFormationException {
        Method currentMethod = parsingNewMethod(blockLines.getFirst());
        for (int i = 1; i < blockLines.size(); i++) {
            checkLine(currentMethod, blockLines, i);
            this.currentVariables.addAll(currentMethod.getLocalVariables());
        }
        GlobalBlock.addMethod(currentMethod);
    }

//        String firstLine=blockLines.getFirst();
//        firstLine=firstLine.replace(VOID,"").trim();
//        String methodName=firstLine.substring(0,firstLine.indexOf("("));
//        String parameters=firstLine.substring(firstLine.indexOf("(")+1,firstLine.lastIndexOf(")"));
//        String[] paramArray=parameters.split(",");
//        for (String param:paramArray){
//            String[] varSpecs=param.split(WHITE_SPACE_REGEX);
//            String type = DEFAULT_TYPE;
//            String varName = DEFAULT_NAME;
//            boolean isFinal=false;
//            if (!param.contains(FINAL)) {
//                type = varSpecs[0];
//                varName = varSpecs[1];
//            }else{
//                isFinal=true;
//                type = varSpecs[1];
//                varName = varSpecs[2];
//            }
//            if (checkVarNameExistence(varName) && checkWithGlobalVars(varName))
//                currentVariables.add(new Variable(type,varName,new Object(),isFinal,true,true));
//            else throw new IllegalFormationException("ERROR: duplicate variables!");
//        }


//    /**
//     * this method checks if the line is a method calling line.
//     *
//     * @param line the line to check.
//     * @throws IllegalFormationException if the calling method doesn't take as number of parameters as the
//     *                                   reserved method, if the number of parameters in the calling method line not as number of parameters
//     *                                   in the original method.
//     */
//    private static void checkMethodCall(String line) throws IllegalFormationException {
//        line = line.trim();
//        String methodName = line.substring(0, line.indexOf(OPEN_BRACKET)).replaceAll(SPACE, EMPTY_LINE);
//        for (Method method : GlobalBlock.getMethodsList()) {
//            if (method.getMethodName().equals(methodName)) {
//                String betweenBracketsVariables = line.substring(line.indexOf(OPEN_BRACKET),
//                        line.lastIndexOf(CLOSE_BRACKET));
//                String[] methodParams = betweenBracketsVariables.split(COMMA);
//                if (method.getLocalVariables().size() != methodParams.length)
//                    throw new IllegalFormationException(METHOD_CALL_ERROR1);
//                for (int i = 0; i < methodParams.length; i++) {
//                    String param = methodParams[i].trim();
//
//                    if (method.getLocalVariables().size() > 0) {
//                        Variable variable = method.getLocalVariables().get(i);
//                        if (checkValue(variable.getType(), param))
//                            return;
//                        if (GlobalBlock.contains(variable.getVarName()) && variable.getVarValue() != null)
//                            return;
//                    } else
//                        throw new IllegalFormationException(METHOD_CALL_ERROR2);
//                }
//            }
//        }
//        throw new IllegalFormationException(METHOD_CALL_ERROR2);
//    }

//    private boolean checkVarLine(String varLine){
//
//    }


//    private void parsingMethodParameters(String[] paramArray) throws IllegalFormationException{
//        for (String param:paramArray){
//            String[] varSpecs=param.split(WHITE_SPACE_REGEX);
//            String type = DEFAULT_TYPE;
//            String varName = DEFAULT_NAME;
//            boolean isFinal=false;
//            if (!param.contains(FINAL)) {
//                type = varSpecs[0];
//                varName = varSpecs[1];
//            }else{
//                isFinal=true;
//                type = varSpecs[1];
//                varName = varSpecs[2];
//            }
//            if (checkVarNameExistence(varName) && checkWithGlobalVars(varName))
//                currentVariables.add(new Variable(type,varName,new Object(),isFinal,true,true));
//            else throw new IllegalFormationException("ERROR: duplicate variables!");
//        }
//    }

    /**
     * this method checks if the name of the method is legal ...
     * @param line - the line of the method name.
     * @return - the name of the method if it is a legal name.
     * @throws IllegalFormationException - if there is error with name of the method.
     */
    private String checkMethodName(String line) throws IllegalFormationException {
        line = line.replace(VOID, "").trim();
        String methodName = line.substring(0, line.indexOf("("));
        if (GlobalBlock.getGlobalVariables().size() > 0)
            for (Variable variable : GlobalBlock.getGlobalVariables())
                if (variable.getVarName().equals(methodName))
                    throw new IllegalFormationException(SAME_VARIABLE_NAME_MSG);
        if (GlobalBlock.getMethodsList().size() > 0)
            for (Method method : GlobalBlock.getMethodsList())
                if (method.getMethodName().equals(methodName))
                    throw new IllegalFormationException(SAME_METHOD_NAME_MSG);
        if (KEYWORDS.contains(methodName))
            throw new IllegalFormationException(RESERVED_KEYWORD_MSG);
        return methodName;
    }

    /**
     * this method is parsing new method if it is legal.
     * @param line - the line of the new method.
     * @return - if the method is legal returns a new methodClass represent on this method, not legal
     * returns exception.
     * @throws IllegalFormationException - if the method is illegal returns exception with appropriate message.
     */
    private Method parsingNewMethod(String line) throws IllegalFormationException {
        LinkedList<Variable> methodParameters = new LinkedList<>();
        String methodName = checkMethodName(line);
        line = line.substring(line.indexOf(OPEN_BRACKET)+1, line.lastIndexOf(CLOSE_BRACKET)).trim();
        if (line.matches(WHITE_SPACE_REGEX) || line.equals(EMPTY_LINE))
            return new Method(methodName,methodParameters);
        String[] paramArray = line.split(COMMA);
        for (String param : paramArray) {
//            System.out.println(param);
            String[] varSpecs = param.trim().split(WHITE_SPACE_REGEX);
//            for (String s:varSpecs) System.out.println(s);
            String type = DEFAULT_TYPE;
            String varName = DEFAULT_NAME;
            boolean isFinal = false;
            if (param.contains(FINAL)) {
                if (varSpecs.length!=3)
                    throw new IllegalFormationException(INAPPROPRIATE_METHOD);
                isFinal = true;
                type = varSpecs[1];
                varName = varSpecs[2];
            } else  {
                if (varSpecs.length!=2)
                    throw new IllegalFormationException(INAPPROPRIATE_METHOD);
                type = varSpecs[0];
                varName = varSpecs[1];
            }
            for (Variable variable : methodParameters)
                if (variable.getVarName().equals(methodName))
                    throw new IllegalFormationException(DUPLICATE_SAME_VARIABLE);
            for (Variable variable : GlobalBlock.getGlobalVariables())
                if (variable.getVarName().equals(methodName))
                    throw new IllegalFormationException(DUPLICATE_SAME_VARIABLE);
            methodParameters.add(new Variable(type, varName, new Object(), isFinal,true,true));
        }
        return new Method(methodName, methodParameters);
    }

//    @Override
//    public boolean contains(String name) {
//        for (Variable variable:currentVariables)
//            if (variable.getVarName().equals(name)) return true;
//        return false;
//    }

//    private boolean checkVarNameExistence(String varName){
//        for (Variable variable:this.currentVariables){
//            if (variable.getVarName().equals(varName)) return false;
//        }
//        return true;
//    }
//    private boolean checkWithGlobalVars(String varName){
//        for (Variable variable:GlobalBlock.getGlobalVariables()){
//            if (variable.getVarName().equals(varName)) return false;
//        }
//        return true;
//    }
}
