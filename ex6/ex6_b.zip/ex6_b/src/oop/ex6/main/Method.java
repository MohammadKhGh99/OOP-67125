package oop.ex6.main;

import java.util.HashMap;
import java.util.LinkedList;
import static oop.ex6.AllHelpingVariables.*;

/**
 * Method's Class represents on each method, it is mean each method in the file has a object from this class
 * and this class has the characters of the method
 */
public class Method {
    // this variable is name of the method
    private String methodName;
    // this LinkedList includes the local variables in this method
    private LinkedList<Variable> localVariables;

    /**
     * Constructor method receives the name of the method and the local variables.
     */
    public Method(String methodName,LinkedList<Variable> localVariable){
        this.localVariables =localVariable;
        this.methodName=methodName;
    }

    /**
     * @return - This method return the local variable of this method.
     */
    public LinkedList<Variable> getLocalVariables(){
        return this.localVariables;
    }

    /**
     * @return - The name of this method.
     */
    public String getMethodName(){return this.methodName;}

    /**
     * This method add all the given variable.
     * @param variables - the given we want to add to this method.
     * @throws IllegalFormationException - illegal things return appropriate message
     */
    public void addAllVariables(LinkedList<Variable> variables) throws IllegalFormationException{
//        for (Variable variable:variables){
//            for (Variable variable1:this.localVariables)
//                if (variable.equals(variable1))
//                    throw new IllegalFormationException(DUPLICATE_SAME_VARIABLE);
//                else {
//                    this.localVariables.add(variable);
//                }
//        }
//        if (this.localVariables.size()>0) return;
        this.localVariables.addAll(variables);
    }

    /**
     * This method add one variable that receive
     */
    public void addVariable(Variable variable){
        this.localVariables.add(variable);
    }

//    public LinkedList<Variable> getGlobalVariables(){
//        return this.globalVariables;
//    }
//    public void updateListVariables(Variable var){
//        this.localVariables.add(var);
//    }

//    public HashMap<String,LinkedList<Variable>> getMethodSpecs(){
//        return this.methodSpecs;
//    }


}
