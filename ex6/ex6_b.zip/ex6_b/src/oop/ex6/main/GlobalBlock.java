package oop.ex6.main;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.regex.Pattern;

import static oop.ex6.AllHelpingVariables.*;

/**
 * This GlobalBlock's class represent to the Global Variable of the file we want to research, all the method
 * and method member are static because there is one global block in each file and we want to add on them,
 * meaning we didn't want instance of them.
 */
public class GlobalBlock{
    // static linkedList of Variable's class indicates to global variables of file
    private static LinkedList<Variable> globalVariables=new LinkedList<>();
    // static linkedList of Method's class indicates to the method of the file
    private static LinkedList<Method> methodsList=new LinkedList<>();

//    private HashMap<Integer, Integer> methodsLines = getMethodsLines(blockLines);
//    private static LinkedList<String> globalBlockLines=new LinkedList<>();

//    public GlobalBlock() {
//        super();
//        this.methodsList=new LinkedList<>()
//    }
//    public static void setBlockLines(LinkedList<String> blockLines){
//        globalBlockLines=blockLines;
//    }


//    @Override

    /**
     * this method reset the two linkedList (Global Variables, Method List)
     */
    public static void reset(){
        globalVariables=new LinkedList<>();
        methodsList=new LinkedList<>();
    }

    /**
     * This method is passing on the lines twice, the first passing is to add the legal global variable,
     * the second passing is on the method, checking the legal methods and add them to LinkedList of method
     * List, otherwise illegal comment... return exception
     * @param blockLines
     * @param startIndexes
     * @param endIndexes
     * @throws IllegalFormationException
     */
    public static void parsingBlock(LinkedList<String> blockLines,LinkedList<Integer> startIndexes,
                                    LinkedList<Integer> endIndexes) throws IllegalFormationException {
        int i = 0;
        while (i < blockLines.size()) { // taking all the global variables, and checking illegal comments.
            String line = blockLines.get(i);
            checkIllegalComments(line);
            if (!checkMethodIndexes(i, startIndexes, endIndexes)) {
                if (!line.matches(VARIABLES_REGEX) && !line.matches(VARIABLE_ASSIGN) && !line.matches(GLOBAL_VARIABLE))
                    throw new IllegalFormationException(GLOBAL_ERROR);
                else {
                    VarLine varLine = new VarLine(GlobalBlock.getGlobalVariables());
                    GlobalBlock.addAllVariables(varLine.parsingLine(line));
                }
            }
            i++;
        }

        for (int j = 0; j < startIndexes.size(); j++) {
            LinkedList<String> methodBlockLines = new LinkedList<>();
            MethodBlock methodBlock = new MethodBlock(GlobalBlock.getGlobalVariables());

            int index = startIndexes.get(j);
            String methLine = blockLines.get(index);
            methodBlockLines.add(methLine);
            index++;
            while (index <= endIndexes.get(j)) {
                methLine = blockLines.get(index);
                methodBlockLines.add(methLine);
                index++;
            }
            methodBlock.parsingBlock(methodBlockLines);
        }
    }

//    private void checkIllegalLine(String line){
//        if ()
//    }

//    /**
//     * this method checks if the line is a method calling line.
//     *
//     * @param line the line to check.
//     * @throws IllegalFormationException if the calling method doesn't take as number of parameters as the
//     *                                   reserved method, if the number of parameters in the calling method line not as number of parameters
//     *                                   in the original method.
//     */
//    private static void checkMethodCall(String line) throws IllegalFormationException {
//        line = line.trim();
//        String methodName = line.substring(0, line.indexOf("(")).replaceAll(" ", "");
//        for (Method method : GlobalBlock.getMethodsList()) {
//            if (method.getMethodName().equals(methodName)) {
//                String betweenBracketsVariables = line.substring(line.indexOf("("), line.lastIndexOf(")"));
//                String[] methodParams = betweenBracketsVariables.split(",");
//                if (method.getLocalVariables().size() != methodParams.length)
//                    throw new IllegalFormationException(METHOD_CALL_ERROR1);
//                for (int i = 0; i < methodParams.length; i++) {
//                    String param = methodParams[i].trim();
//
//                    if (method.getLocalVariables().size() > 0) {
//                        Variable variable = method.getLocalVariables().get(i);
//                        if (checkValue(variable.getType(), param))
//                            return;
//                        if (GlobalBlock.contains(variable.getVarName()) && variable.getVarValue() != null)
//                            return;
//                    } else
//                        throw new IllegalFormationException(METHOD_CALL_ERROR2);
//                }
//            }
//        }
//        throw new IllegalFormationException(METHOD_CALL_ERROR2);
//    }

//    private static HashMap<Integer, Integer> getMethodsLines(LinkedList<String> codeLines) throws IllegalFormationException {
//        HashMap<Integer, Integer> methodsLinesNums = new HashMap<>();
//        int i = 0;
//        while (i < codeLines.size()) {
//            int methodLinesCount = 0;
//            String line = codeLines.get(i);
//            if (line.matches(METHOD_REGEX)) {
//                int methodStart = i;
//                methodLinesCount++;
//                int parenthesesCount = 1;
//                i++;
//                while (parenthesesCount > 0 && i < codeLines.size()) {
//                    line = codeLines.get(i);
//                    methodLinesCount++;
//                    if (line.matches(METHOD_REGEX))
//                        throw new IllegalFormationException(METHOD_IN_METHOD);
//                    if (line.matches(IF_REGEX) || line.matches(WHILE_REGEX)) {
//                        parenthesesCount++;
//                    } else if (line.matches(".+\\{\\s*")) {
//                        throw new IllegalFormationException(NOT_IF_OR_WHILE);
//                    } else if (line.matches("\\s*}\\s*")) {
//                        if (parenthesesCount==1) {
//                            String returnLine = codeLines.get(i - 1);
//                            if (!returnLine.matches(RETURN_REGEX))
//                                throw new IllegalFormationException(RETURN_ERROR);
//                        }
//                        parenthesesCount--;
//                    }
//                    i++;
//                }
//                if (parenthesesCount == 0)
//                    methodsLinesNums.put(methodStart, methodStart + methodLinesCount - 1);
//                else throw new IllegalFormationException(BRACKETS_PROBLEM_MSG);
//            } else i++;
//        }
//        return methodsLinesNums;
//    }

    /**
     * this method checks if the given index is in the indexes of the methods indexes.
     *
     * @param lineIndex    the required index to check.
     * @param startIndexes linked list that contains when all the methods start.
     * @param endIndexes   linked list that contains when all the methods ends.
     * @return true if the index in the methods indexes, false otherwise.
     */
    private static boolean checkMethodIndexes(int lineIndex, LinkedList<Integer> startIndexes,
                                              LinkedList<Integer> endIndexes) {
        for (int i = 0; i < startIndexes.size(); i++) {
            int startIndex = startIndexes.get(i);
            int endIndex = endIndexes.get(i);
            if (lineIndex >= startIndex && lineIndex <= endIndex) return true;
        }
        return false;
    }

    /**
     * this method checks illegal comments.
     * @param commentLine - the line of the comment.
     * @throws IllegalFormationException - if the comment illegal returns exception with appropriate message.
     */
    private static void checkIllegalComments(String commentLine) throws IllegalFormationException{
        if (commentLine.matches(ILLEGAL_COMMENTS))
            throw new IllegalFormationException(ILLEGAL_COMMENTS_MSG);
    }

//    private static void checkGlobalVariables(String line,int index) throws IllegalFormationException{
//        HashMap<Integer, Integer> methodsLines = getMethodsLines(blockLines);
//        LinkedList<Integer> startIndexes = new LinkedList<>(methodsLines.keySet());
//        LinkedList<Integer> endIndexes = new LinkedList<>(methodsLines.values());
//
//        if (line.matches(VARIABLES_REGEX) && !checkMethodIndexes(index, startIndexes, endIndexes)) {
//                line = line.replace(SEMI_COLON, EMPTY_LINE);
//            VarLine varLine = new VarLine(GlobalBlock.getGlobalVariables());
//            GlobalBlock.addAllVariables(varLine.parsingLine(line));
//        }
//    }

    /**
     * this method checks if the string contains in global variables
     * @param name - the string wants to check
     * @return - true if it is global variable, otherwise false
     */
    public static boolean contains(String name) {
        for (Variable variable:globalVariables) {
            if (variable.getVarName().equals(name))
                return true;
        }
        return false;
    }

    /**
     * this method adds all the global variables to the linked list
     * @param variables - the legal variables want to add
     */
    public static void addAllVariables(LinkedList<Variable> variables){
        globalVariables.addAll(variables);
    }

    /**
     * this method adds method to the method linked list
     * @param method - the legal method wants to add
     */
    public static void addMethod(Method method){
        methodsList.add(method);
    }

    /**
     * this method gets the linkedList of global variables
     * @return - the global variables
     */
    public static LinkedList<Variable> getGlobalVariables(){
        return globalVariables;
    }

    /**
     * this method gets the linkedList of methodList
     * @return - the method list
     */
    public static LinkedList<Method> getMethodsList() {
        return methodsList;
    }
}
