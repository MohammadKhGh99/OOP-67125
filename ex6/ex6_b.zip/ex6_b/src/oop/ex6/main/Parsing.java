package oop.ex6.main;

//import java.io.File;

import java.util.*;

import static oop.ex6.AllHelpingVariables.*;

/**
 * This class parsing the file has two static method.
 */
public class Parsing {

//    private static LinkedList<Variable> globalVariablesList = new LinkedList<>();
//    private static LinkedList<Method> methodsList = new LinkedList<>();

    /**
     * parsing the file, put the method in hash map with the line of start method and finish
     * @param codeLines - the lines of the file
     * @throws IllegalFormationException - Exception >> illegal things with appropriate message
     */
    public static void parsingFile(LinkedList<String> codeLines) throws IllegalFormationException {

        HashMap<Integer, Integer> methodsLines = getMethodsLines(codeLines);
        LinkedList<Integer> startIndexes = new LinkedList<>(methodsLines.keySet());
        LinkedList<Integer> endIndexes = new LinkedList<>(methodsLines.values());

        GlobalBlock.parsingBlock(codeLines, startIndexes, endIndexes);


//        for (Variable variable:GlobalBlock.getGlobalVariables()){
//            System.out.println(variable.getType()+" "+variable.getVarName());
//        }

    }

//    private static void checkIfCondition(String ifLine) {
//
//    }

//    private static String checkMethodName(String line) throws IllegalFormationException {
//        line = line.replace(VOID, "").trim();
//        String methodName = line.substring(0, line.indexOf("("));
//        if (GlobalBlock.getGlobalVariables().size() > 0)
//            for (Variable variable : GlobalBlock.getGlobalVariables())
//                if (variable.getVarName().equals(methodName))
//                    throw new IllegalFormationException(SAME_VARIABLE_NAME_MSG);
//        if (GlobalBlock.getMethodsList().size() > 0)
//            for (Method method : GlobalBlock.getMethodsList())
//                if (method.getMethodName().equals(methodName))
//                    throw new IllegalFormationException(SAME_METHOD_NAME_MSG);
//        if (KEYWORDS.contains(methodName))
//            throw new IllegalFormationException(RESERVED_KEYWORD_MSG);
//        return methodName;
////        return true;
//    }
//
//    private static Method parsingNewMethod(String line) throws IllegalFormationException {
//        LinkedList<Variable> methodParameters = new LinkedList<>();
//        String methodName = checkMethodName(line);
//        line = line.substring(line.indexOf("(")+1, line.lastIndexOf(")")).trim();
//        if (line.matches(WHITE_SPACE_REGEX))
//            return new Method(methodName,methodParameters);
//        String[] paramArray = line.split(",");
////        if ()
//        for (String param : paramArray) {
////            System.out.println(param);
//            String[] varSpecs = param.split(WHITE_SPACE_REGEX);
////            for (String s:varSpecs) System.out.println(s);
//            String type = DEFAULT_TYPE;
//            String varName = DEFAULT_NAME;
//            boolean isFinal = false;
//            if (!param.contains(FINAL)) {
//                if (varSpecs.length!=2)
//                    throw new IllegalFormationException(INAPPROPRIATE_METHOD);
//                type = varSpecs[0];
//                varName = varSpecs[1];
//
//            } else  {
//                if (varSpecs.length!=3)
//                    throw new IllegalFormationException(INAPPROPRIATE_METHOD);
//                isFinal = true;
//                type = varSpecs[1];
//                varName = varSpecs[2];
//            }
//            for (Variable variable : methodParameters)
//                if (variable.getVarName().equals(methodName))
//                    throw new IllegalFormationException(DUPLICATE_SAME_VARIABLE);
//            for (Variable variable : GlobalBlock.getGlobalVariables())
//                if (variable.getVarName().equals(methodName))
//                    throw new IllegalFormationException(DUPLICATE_SAME_VARIABLE);
//            methodParameters.add(new Variable(type, varName, new Object(), isFinal, true));
//        }
//        return new Method(methodName, methodParameters);
//    }
//    private static boolean checkVarNameExistence(String varName,LinkedList<Variable> currentVariables){
//        for (Variable variable:currentVariables){
//            if (variable.getVarName().equals(varName)) return false;
//        }
//        return true;
//    }
//    private static boolean checkWithGlobalVars(String varName){
//        for (Variable variable:GlobalBlock.getGlobalVariables()){
//            if (variable.getVarName().equals(varName)) return false;
//        }
//        return true;
//    }

//    /**
//     * this method checks if the line is a method calling line.
//     *
//     * @param line the line to check.
//     * @throws IllegalFormationException if the calling method doesn't take as number of parameters as the
//     *                                   reserved method, if the number of parameters in the calling method line not as number of parameters
//     *                                   in the original method.
//     */
//    private static void checkMethodCall(String line) throws IllegalFormationException {
//        line = line.trim();
//        String methodName = line.substring(0, line.indexOf("(")).replaceAll(" ", "");
//        for (Method method : GlobalBlock.getMethodsList()) {
//            if (method.getMethodName().equals(methodName)) {
//                String betweenBracketsVariables = line.substring(line.indexOf("("), line.lastIndexOf(")"));
//                String[] methodParams = betweenBracketsVariables.split(",");
//                if (method.getLocalVariables().size() != methodParams.length)
//                    throw new IllegalFormationException(METHOD_CALL_ERROR1);
//                for (int i = 0; i < methodParams.length; i++) {
//                    String param = methodParams[i].trim();
//
//                    if (method.getLocalVariables().size() > 0) {
//                        Variable variable = method.getLocalVariables().get(i);
//                        if (checkValue(variable.getType(), param))
//                            return;
//                        if (GlobalBlock.contains(variable.getVarName()) && variable.getVarValue() != null)
//                            return;
//                    } else
//                        throw new IllegalFormationException(METHOD_CALL_ERROR2);
//                }
//            }
//        }
//        throw new IllegalFormationException(METHOD_CALL_ERROR2);
//    }

//    /**
//     * this method checks if the given index is in the indexes of the methods indexes.
//     *
//     * @param lineIndex    the required index to check.
//     * @param startIndexes linked list that contains when all the methods start.
//     * @param endIndexes   linked list that contains when all the methods ends.
//     * @return true if the index in the methods indexes, false otherwise.
//     */
//    private static boolean checkMethodIndexes(int lineIndex, LinkedList<Integer> startIndexes,
//                                              LinkedList<Integer> endIndexes) {
//        for (int i = 0; i < startIndexes.size(); i++) {
//            int startIndex = startIndexes.get(i);
//            int endIndex = endIndexes.get(i);
//            if (lineIndex >= startIndex && lineIndex <= endIndex) return true;
//        }
//        return false;
//    }

//    private String checkAndGetMethodName(String methodLine){
//
//    }

    /**
     * this method parses on the files searching on the methods of the file, put them in hash map with two
     * Integers indicates the line of the start of specific method and the end of it.
     * @param codeLines - the lines of the file
     * @return - HashMap contains the methods of the file
     * @throws IllegalFormationException - Exception if the method not illegal like no return...
     */
    private static HashMap<Integer, Integer> getMethodsLines(LinkedList<String> codeLines)
            throws IllegalFormationException {
        HashMap<Integer, Integer> methodsLinesNums = new HashMap<>();
        int i = 0;
        while (i < codeLines.size()) {
            int methodLinesCount = 0;
            String line = codeLines.get(i);
            if (line.matches(METHOD_REGEX)) {
                int methodStart = i;
                methodLinesCount++;
                int parenthesesCount = 1;
                i++;
                while (parenthesesCount > 0 && i < codeLines.size()) {
                    line = codeLines.get(i);
                    methodLinesCount++;
                    if (line.matches(METHOD_REGEX))
                        throw new IllegalFormationException(METHOD_IN_METHOD);
                    if (line.matches(IF_REGEX) || line.matches(WHILE_REGEX)) {
                        parenthesesCount++;
                    } else if (line.matches(ILLEGAL_BLOCK_START)) {
                        throw new IllegalFormationException(NOT_IF_OR_WHILE);
                    } else if (line.matches(BLOCK_END)) {
                        if (parenthesesCount == 1) {
                            String returnLine = codeLines.get(i - 1);
                            if (!returnLine.matches(RETURN_REGEX))
                                throw new IllegalFormationException(RETURN_ERROR);
                        }
                        parenthesesCount--;
                    }
                    i++;
                }
                if (parenthesesCount == 0)
                    methodsLinesNums.put(methodStart, methodStart + methodLinesCount - 1);
                else throw new IllegalFormationException(BRACKETS_PROBLEM_MSG);
            } else i++;
        }
        return methodsLinesNums;
    }

//    private boolean checkCallingMethod(String callingLine){
//        callingLine=callingLine.replace(";","");
//        String methodName=callingLine.substring(0,callingLine.indexOf("(")).trim();
//        String parameters=callingLine.substring(callingLine.indexOf("(")+1,callingLine.lastIndexOf(")"));
//        for (Method method:methodsList){
//            if (method.getMethodName().equals(methodName)){
//                String[] varsArray = parameters.split(",");
////                    if (method.getLocalVariables().size()>0)
//                        for (int i=0;i<varsArray.length;i++){
//                            if (varsArray[i].trim().matches(VAR_VALUE_REGEX) || ){
//
//                            }else if (method.getLocalVariables().size()>0)
//                                return false;
//                        }
//            }
//        }
//        return true;
//    }

//    private boolean checkWhiteSpacesBetweenVars(String toCheck){
//        for (int i=0;i<toCheck.length();i++){
//            if ()
//        }
//    }
}
