package parser;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

interface Regex {
    //a regex for a legal double
    public final static String CHAR = "char";
    public final static String INT =  "int";
    public final static String VOID =  "void";
    public final static String DOUBLE = "double";
    public final static String BOOLEAN = "boolean";
    public final static String STRING = "String";
    public final static String IF = "if";
    public final static String WHILE = "while";
    public final static String STATEMENTS = "if|while|return";
    public final static String RETURN = "return";
    public final static String FALSE = "false";
    public final static String TRUE = "true";
    public final static String FINAL = "final";
    public final static String TYP_REG = "int|double|String|boolean|char";
    public final static String COMMA_END = "+[,]?)*";
    public final static String SP = "\\s+";
    public final static String VARNAME_REG = "\\s*_?+([A-Za-z_{2}]+)\\d*\\s*";
    public final static String FINAL_PARAM = "\\s*final\\s+)?(";
    public final static String METHOD_PARAMS =  "\\(((((" +FINAL_PARAM + TYP_REG + ")\\s+(^_*)?+([a-zA-Z]+)+\\d" +
            "*+[,]?\\s*)*)|\\s*)\\)\\s*\\{";
    public final static String METHOD_NAME = "\\s*([a-zA-Z]+\\w*)";
    public final static String METHOD_CALL = METHOD_NAME  + "+\\(\\s*+(.*?)\\s*+\\)\\s*+\\;";
    public final static String SEMICOL = ";";
    public final static String OPENBRACK = "(";
    public final static String CLOSEBRACK = ")";
    public final static String OPENBRACK2 = "{";
    public final static String CLOSEBRACK2 = "}";
    public final static String DOUBLE_REG = "\\s*(-{0,1}+\\d+\\.{0,1}+\\d*)\\s*";
    //a regex for a legal int
    public final static String INT_REG = "\\s*(-{0,1}+\\d+)\\s*";
    public final static String CHAR_REG = "\'.\'";
    public final static String STRING_REG = "\"+(.*)\"+";
    public final static String COMMENT_REG = "((^\\/\\/.*)|(^(\\/*\\*|\\/*).*\\/$)|(\\s*))";
    public final static String EXIT_BARCKET = "\\s*\\}\\s*";

    public final static String SYMBOL="\\=|[(]|[)]|[{]|[}]|\\;|[||]|&&|,";
    public final static String[] SYMBOLS = {
            "=", "(", ")", "{", "}", ";", "||", "&&", ","
    };
    public final static ArrayList<String> SYMBOL_STORAGE = new ArrayList<>(Arrays.asList(SYMBOLS));
    public final static String EQUAL = "=";
    public final static String KEYWORD = "(int)|(char)|(boolean)|(void)|(true)|(false)|(double)|(String)|(return)";
    public final static String OR = "|";
    public final static String BOOL_REG = "\\s*true\\s*|\\s*false\\s*";
    public final static String RETURN_REG = "\\s*return\\s*;\\s*";
    public final static String LEGAL_BOOL = BOOL_REG + OR + INT_REG + OR + DOUBLE_REG + OR + VARNAME_REG;
    public final static String LEGAL_CONDITION2 = "(" + LEGAL_BOOL + ")" + "+((\\|\\|)|&&)+" + "\\1";

    public final static String expression = "\\s*+\\(\\s*+(.*?)\\s*+\\)\\s*+\\{\\s*+";

    public final static String IF_REGEX = "\\s*(if)\\s*+\\(\\s*+(.*?)\\s*+\\)\\s*+\\{\\s*+";



    public final static String IF_REGEX2 = "\\s*(if)\\s*\\(\\s*(("+BOOL_REG+")|("+INT_REG+
            ")|("+DOUBLE_REG+")|("+VARNAME_REG+"))\\s*\\)\\s*\\{\\s*";
    public final static String WHILE_REGEX = "\\s*(while)\\s*\\(\\s*(("+BOOL_REG+")|("+INT_REG+")|("
            +DOUBLE_REG+")|("+VARNAME_REG+"))\\s*\\)\\s*\\{\\s*";
    public final static String BELONG_TO_VAR = "final|" + TYP_REG + "|" + VARNAME_REG;
    public final static String LEGAL_VAL = INT_REG + OR +DOUBLE_REG + OR + STRING_REG + OR + CHAR_REG + OR + BOOL_REG +
            OR + VARNAME_REG;
    public final static String VARDEC = "\\s*(" + TYP_REG + ")\\s*" + "(" + VARNAME_REG + ")\\s*=\\s*(\\d|" +
            LEGAL_VAL + ")+(\\s)*";
    public final static String FINALVARDEC = "\\s*final\\s*" + VARDEC + SEMICOL;
    public final static String[] TYPES_REGEX2 = {INT_REG,DOUBLE_REG,STRING_REG,CHAR_REG,BOOL_REG};
    public final static String NO_ASSIGN = "\\s*(" + TYP_REG + ")" + "\\s" + "(" + VARNAME_REG + ");";
    public final static String METHOD_DEF_HELP = "^(void)" + METHOD_NAME;
    public final static String BRACKET_1 = "[(]";
    public final static String METHOD_DEF = METHOD_DEF_HELP + METHOD_PARAMS ;
    public final static String[] TYPES = {"int","double","String","char","boolean"};
    public final static String COMMA = ",";
    public final static String PARAM = "(" + FINAL + "\\s)?" + "(" + TYP_REG + ")" + SP + "(" + VARNAME_REG + ")";


    public final static String VARDEC_Semi = VARDEC + SEMICOL;
    public final static String ASSIGN = "\\s*" + VARNAME_REG + "\\s*=\\s*(" + LEGAL_VAL + ")" + SEMICOL ;

    //complex varDec
    String NAME = "\\s*((_?(\\w+)\\d*(\\s*=\\s*\\s*";
    String VALUE = "(\\d+|\"(.*)\"|'.?'|_?(\\w+)\\d*|true|false|(-{0,1}+\\d+[\\.]{0,1}+\\d+))\\s*\\s*)?\\s*";
    String MOREDEC = "+(_?(\\w+)\\d*(\\s*=\\s*\\s*" + VALUE + "));\\s*";
    String FINALDEC = "\\s*(final\\s+)?(";
    String COMPLEX = FINALDEC + TYP_REG + CLOSEBRACK + NAME + VALUE + ",\\s*)" + MOREDEC;


    //patterns for isValid method

    static Pattern final_var_dec = Pattern.compile(FINALVARDEC);
    static Pattern assign = Pattern.compile(ASSIGN);
    static Pattern no_assign = Pattern.compile(NO_ASSIGN);
    static Pattern varDec = Pattern.compile(VARDEC_Semi);
    static Pattern comment = Pattern.compile(COMMENT_REG);
    static Pattern ifRegex = Pattern.compile(IF_REGEX);
    static Pattern exitB = Pattern.compile(EXIT_BARCKET);
    static Pattern whileRegex = Pattern.compile(WHILE_REGEX);
    static Pattern retuurnRegex = Pattern.compile(RETURN_REG);
    static Pattern methodCall = Pattern.compile(METHOD_CALL);
    static Pattern methodDef = Pattern.compile(METHOD_DEF);
    static Pattern complexDec = Pattern.compile(COMPLEX);

}


//^(void)\s*([a-zA-Z]+\w*)[(](((int|double|String|boolean|char)\s+(^_*)?+([a-zA-Z]+)+\d*+[,]?\s*)*)
//
//
//
//        \s*([a-zA-Z]+\w*)(\s*\(((\s*\w*\s*,\s*)*\w+)*)\);



///MESOBA555 LAKOL ESHE
//\s*(int|double|String|boolean|char)\s*((_?(\w+)\d*(\s*=\s*\s*(\d+|"(.*)"|'.?'|_?(\w+)\d*|true|false|(-{0,1}+\d+[\.]{0,1}+\d+))\s*\s*)?\s*,\s*)+(_?(\w+)\d*(\s*=\s*\s*(\d+|"(.*)"|'.?'|_?(\w+)\d*|true|false|(-{0,1}+\d+[\.]{0,1}+\d+))\s*\s*)?\s*));\s*