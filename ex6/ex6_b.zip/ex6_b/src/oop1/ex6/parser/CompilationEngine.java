package parser;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

abstract public class CompilationEngine implements Regex {

    private static String SPACE = " ";
    private static String NOTHING = "";
    private static Method methodObj = new Method();
    private static ArrayList<String> wasClledAndFound = new ArrayList<>();//for methods
    private static ArrayList<String> wasClledAndFoundVar = new ArrayList<>();//for vars
    private static boolean WASCALLED = false;
    private static boolean WASCALLEDVAR = false;


    /**
     *  by this method we check if there is a matching between the typ of the var ante the val
     * @param value the value that we want to check
     * @param type the typ that we want to check
     * @return boolean if there is matching
     * @throws Error
     */
    private static boolean typMatchVal(String value, String type) throws Error {
        if(type == null && value == null){
            throw new Error();
        }
        Pattern p;
        Matcher m = null;
        if (type.equals(INT)) {
            p = Pattern.compile(INT_REG);
            m = p.matcher(value);
        } else if (type.equals(DOUBLE)) {
            p = Pattern.compile(DOUBLE_REG);
            m = p.matcher(value);
        } else if (type.equals(CHAR)) {
            p = Pattern.compile(CHAR_REG);
            m = p.matcher(value);
        } else if (type.equals(BOOLEAN)) {
            p = Pattern.compile(LEGAL_BOOL);
            m = p.matcher(value);
        } else if (type.equals(STRING)) {
            p = Pattern.compile(STRING_REG);
            m = p.matcher(value);
        } else {
            throw new Error();
        }

        if (m.matches()) {//if there is matching
            return true;
        } else {
            throw new Error();
        }

    }


//    /**
//     *
//     * @param scopeObj the scope obj
//     * @param varName the name of our variable
//     * @param typ the typ  of our variable
//     * @param value the  value of our variable
//     * @param isFinal bool if it's final or not
//     * @return bool if the all is legal and we added the var
//     * @throws Error the error that we will throw
//     */
//    private static boolean check_ADD_Help(Scope scopeObj, String varName, String typ, String value, boolean isFinal)
//            throws Error {
//        if (scopeObj.contains(varName)) {//if the var is already exsists
//            typ = scopeObj.typByName(varName);
//            String special = value;//the value is a varname
//            String realValue = scopeObj.valueByName(special); //the value = varname\\get varname(value) real value
//            if (typMatchVal(realValue, typ)) {//check matching
//                scopeObj.addVar(varName, typ, value, isFinal, true,false);
//                return true;
//            } else {
//                throw new Error();
//            }
//        } else {
//            throw new Error();
//        }
//    }
//

    /**
     *by this method we manage the case in which we have a varname value
     * @param scopeObj the scope obj
     * @param varName the name of our variable
     * @param typ the typ  of our variable
     * @param value the  value of our variable
     * @param isFinal bool if it's final or not
     * @return bool if the all is legal and we added the var
     * @throws Error the error that we will throw
     */
    private static boolean VarNameCase(Scope scopeObj, String varName, String typ, String value, boolean isFinal)
            throws Error{
        if (scopeObj.contains(value)) {//check if the var exsists
            if(scopeObj.isParam(value)){//check if the var is param(arg) of the method
                if(scopeObj.typByName(value).equals(typ)){
                    return true;
                }
                throw new Error();
            }
            //if it's not param
            else if (typMatchVal(scopeObj.valueByName(value), scopeObj.typByName(value))) {//check matching
                if (scopeObj.contains(varName)) {
                    throw new Error();
                }
                scopeObj.addVar(varName, typ, scopeObj.getVariable(value).getVal(), isFinal, true,false);
                return true;
            }
        }
        return false;
    }


    /**
     * check if the all is legal(containning...)then add
     * @param typ typ of var
     * @param value val of var
     * @param varName name of var
     * @param isFinal isFinal of var
     * @param scopeObj
     * @return bool val if it sucess
     * @throws Error the error that we will throw
     */
    private static boolean Check_ADD(String typ, String value, String varName, boolean isFinal, Scope scopeObj)
            throws Error{
        Pattern p1;
        Matcher m1;
        p1 = Pattern.compile(VARNAME_REG);


        m1 = p1.matcher(value);

        Pattern p;
        Matcher m;
        //check if it val match to a regex
        for (String regex : TYPES_REGEX2) {
            p = Pattern.compile(regex);
            m = p.matcher(value);
            if (m.matches()) {
                if (typMatchVal(value, typ)) {
                        scopeObj.addVar(varName, typ, value, isFinal, true,false);
                        return true;
                }
            }
        }
        if (m1.matches()) {
            if (VarNameCase(scopeObj, varName, typ, value, isFinal)) {
                return true;
            }
        }

        throw new Error();
    }


    /**
     * by this method we will compile the final var case
     * @param line line to check
     * @param m matcher
     * @param scopeObj our scope
     * @return bool val
     * @throws Error error that we will throw
     */
    protected static boolean compileFinal(String line, Matcher m, Scope scopeObj) throws Error {
        if(m.matches()) {
            String typ = m.group(1);
            String varName = m.group(2);
            String value = m.group(4);
            //check if legal then addd
            if (Check_ADD(typ, value, varName, true, scopeObj)) {
                return true;
            }
        }
        throw new Error();
    }

    /**
     * by this method we will compile the init without val var case
     * @param line line to check
     * @param m matcher
     * @param scopeObj our scope
     * @return bool val
     * @throws Error error that we will throw
     */
    protected static boolean compileInit(String line, Matcher m, Scope scopeObj) throws Error {
        if (m.matches()) {
            String varName = m.group(2);
            String typ = m.group(1);
            if(!scopeObj.contains(varName)) {
                scopeObj.addVar(varName, typ, null, false, true, false);//init without value
                return true;
            }
            throw new Error();
        }
        throw new Error();
    }

    /**
     * by this method we will compile the  var assign case
     * @param line line to check
     * @param m1 matcher
     * @param scopeObj our scope
     * @return bool val
     * @throws Error error that we will throw
     */
    protected static boolean compileVarAssign(String line, Matcher m1, Scope scopeObj) throws Error {
        if (m1.matches()) {
            String name = m1.group(1);
            if (scopeObj.contains(name) && !scopeObj.isFinal(name)) {
                String val = m1.group(2);
                if (Check_ADD(scopeObj.typByName(name), val, name, false, scopeObj)) {
                    return true;
                }
            }
            throw new Error();
        }
        return true;
    }

    /**
     * by this method we will compile the  var dec case
     * @param line line to check
     * @param m matcher
     * @param scopeObj our scope
     * @return bool val
     * @throws Error error that we will throw
     */
    protected static boolean compileVarDec(String line, Matcher m, Scope scopeObj)  throws Error {
        m.reset(line);
        if (m.matches()) {
            String typ = m.group(1);
            String varName = m.group(2);
            String val = m.group(4);
            if (!scopeObj.isFinal(varName)) {
                if (Check_ADD(typ.trim(), val, varName.trim(), false, scopeObj)) {
                    return true;
                }
            }
        }
        throw new Error();//we cannot assign a new val to a final var

    }

    /**
     * by this method we will compile the if while statements
     * @param line line to check
     * @param m1 matcher
     * @param scopeObj our scope
     * @return bool val
     * @throws Error error that we will throw
     */
    protected static boolean compileIfWhile(String line, Matcher m1, Scope scopeObj) throws Error {
        if(scopeObj.parentScope == null){
            throw new Error();
        }
        String[] params = line.split("\\(|\\)|&{2}|\\|{2}");//split by operator
        String[] x = Arrays.copyOfRange(params, 1, params.length - 1); //get  between brackets
        Pattern p;
        Matcher m;
        int flag = 0;//if matching
        //check matching
        for (String param : x) {
            for (String regex : TYPES_REGEX2) {
                p = Pattern.compile(regex);
                m = p.matcher(param);
                if (m.matches()) {
                    flag = 1;
                    break;
                }
            }
            if (flag == 1) {
                flag = 0;
                continue;
            }
            //check the varname case
            p = Pattern.compile(VARNAME_REG);
            m = p.matcher(param);
            if (m.matches()) {
                if (scopeObj.contains(param.trim()) && checkIfType(scopeObj.typByName(param.trim())) &&
                        scopeObj.valueByName(param.trim()) != null ){
                    continue;
                }
                else{
                    wasClledAndFoundVar.add(param.trim());
                }
            }
            throw new Error();
        }

        return true;
    }

    /**
     * by this method we will check if we have a legal typ in the if while statement
     * @param type typ of var
     * @return bool
     */
    private static boolean checkIfType(String type) {
        if (!type.equals(INT) && !type.equals(DOUBLE) && !type.equals(BOOLEAN)) {
            return false;
        }
        return true;
    }


    /**
     *by this method we will know if the method was called before this time and not founded
     * @return boolean
     */
    private static boolean wasCalled() {
        return WASCALLED;

    }



    /**
     * compile the method call case
     * @param line the line that we will check
     * @param m9 the matcher which appropriate to this case
     * @param scopeObj the scope obj which cointains as
     * @return a bool val that will tell as if the compile succeed
     * @throws Error the error that we will throw
     */
    protected static boolean compileMethodCall(String line, Matcher m9, Scope scopeObj) throws Error  {
        String calledMehtodName = m9.group(1);
        String params = m9.group(2);
        String[] separateParams = params.split(COMMA);//split by comma
        if (methodObj.contains(calledMehtodName)) {//check of method declared before
            ArrayList<String> methodTyps = methodObj.getMethodTyps(calledMehtodName);
            if (methodTyps.size() != separateParams.length) {
                throw new Error();
            } else {
                for (int idx = 0; idx < methodTyps.size(); idx++) {
                    if (typMatchVal(separateParams[idx], methodTyps.get(idx))) {//check matching between params
                        continue;//there is matching so continue
                    } else {
                        throw new Error();//no matching between typ and val
                    }
                }
                return true;
            }
        } else {
            wasClledAndFound.add(calledMehtodName);//to save if not found
        }
        if (wasCalled()) {
            WASCALLED = false;
            return true;
        }
        throw new Error();
    }

    /**
     *compile the method def case
     * @param line the line that we will check
     * @param m10 the matcher which appropriate to this case
     * @param scopeObj the scope obj which cointains as
     * @return a bool val that will tell as if the compile succeed
     * @throws Error the error that we will throw
     */
    protected static boolean compileMethodDef(String line, Matcher m10, Scope scopeObj) throws Error {
        String methodName = m10.group(2);
        String params = m10.group(3);
        ArrayList<String> lst1 = new ArrayList<>();
        ArrayList<String> methodTyps = new ArrayList<>();
        String[] separateParams = params.split(COMMA);//split by comma
        if (wasClledAndFound.contains(methodName)) {//check if it was called before it was declared
            WASCALLED = true;
        }

        for (String str : separateParams) {
            if (!str.equals(NOTHING)) {
                lst1.add(str.trim());
            }
        }
        varFinalOrNot(lst1, methodTyps, scopeObj);//check final param or not
        if (!methodObj.contains(methodName)) {
            methodObj.add(methodName, methodTyps);
            return true;
        }
        throw new Error();
    }


    /**
     * manages the case of final var and not final var
     * @param lst1 lst to check
     * @param methodTyps lst of types of method
     * @param scopeObj our scope
     * @return bool
     * @throws Error error to throw
     */
    static boolean varFinalOrNot(ArrayList<String> lst1, ArrayList<String> methodTyps, Scope scopeObj) throws Error {
        if(lst1.size() == 1 && lst1.get(0).trim().equals(NOTHING) || lst1.size() == 0){
            return true;
        }
        else{
            for (String s : lst1) {
                String[] tokens = s.split(SPACE);
                if (tokens[0] == null) {
                    throw new Error();
                } else if (tokens[0].equals(FINAL)) {
                    methodTyps.add(tokens[1]);
                    scopeObj.addVar(tokens[2], tokens[1], null, true, true, true);
                    return true;
                } else {
                    methodTyps.add(tokens[0]);
                    scopeObj.addVar(tokens[1], tokens[0], null, false, true, true);
                    return true;
                }
            }
        }
        throw new Error();
    }

    /**
     *compile complex dec
     * @param line the line that we will check
     * @param m11 the matcher which appropriate to this case
     * @param scopeObj the scope obj which cointains as
     * @return a bool val that will tell as if the compile succeed
     * @throws Error the error that we will throw
     */
    protected static boolean compileComplexDec(String line, Matcher m11, Scope scopeObj, Matcher finalMatch
            , Matcher initMatch, Matcher varDecMatch) throws Error {
        ArrayList<String> lst1 = new ArrayList<>();
        String legal, toKeep, final_Dec = m11.group(1);
        //separate
        if (final_Dec != null) {
            toKeep = final_Dec + m11.group(2) + SPACE;
            legal = final_Dec + m11.group(2) + SPACE;
        } else {
            toKeep = m11.group(2) + SPACE;
            legal = m11.group(2) + SPACE;
        }
        String declerations = m11.group(3);
        String[] splitComma = declerations.split(COMMA);
        //get separated tokens
        for (String str : splitComma) {
            if (!str.equals(NOTHING)) {
                lst1.add(str.trim());
            }
        }
        ArrayList<String> collect = new ArrayList<>();
        for (String s : lst1) {
            s += SEMICOL;
            legal += s;
            collect.add(legal);
            legal = toKeep;
        }
        //select witch matching
        select(collect, scopeObj, final_Dec, finalMatch, initMatch, varDecMatch);
        return true;
    }


    /**
     *by this method we will select the appropreiate compile
     * @param collect the array
     * @param scopeObj our scope
     * @param final_Dec matcher
     * @param finalMatch matcher
     * @param initMatch matcher
     * @param varDecMatch matcher
     * @throws Error
     */
    public static void select(ArrayList<String> collect, Scope scopeObj, String final_Dec, Matcher finalMatch
            , Matcher initMatch, Matcher varDecMatch) throws Error {
        for (String s1 : collect) {
            if (final_Dec != null) {
                if (!s1.contains(EQUAL)) {//final should be declared with value
                    throw new Error();
                } else {
                    compileFinal(s1, finalMatch, scopeObj);
                }
            } else {
                if (s1.contains(EQUAL)) {
                    compileVarDec(s1, varDecMatch, scopeObj);
                } else {
                    compileInit(s1, initMatch, scopeObj);
                }
            }
        }
    }

    /**
     * resets the the static fields,in order to avoid problems if you made a compile for another time\file
     */
    public static void clearData()
    {
        methodObj = new Method();
        wasClledAndFound = new ArrayList<>();
        WASCALLED = true;
    }
}
