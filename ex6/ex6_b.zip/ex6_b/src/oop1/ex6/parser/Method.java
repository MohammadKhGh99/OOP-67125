package parser;

import java.util.ArrayList;
import java.util.HashMap;

public class Method {

    private HashMap<String,ArrayList<String>> methods;


    Method(){
        methods = new HashMap<>();
    }

    /**
     * get lst of types
     * @param methodName
     * @return
     */
    public ArrayList<String> getMethodTyps(String methodName){
        return methods.get(methodName);
    }

    /**
     * check contains
     * @param methodName
     * @return
     */
    public boolean contains(String methodName){
        for(String name : methods.keySet()){
            if(name.equals(methodName)){
                return true;
            }
        }
        return false;
    }

    /**
     * add
     * @param methodName method to add
     * @param types the tytpes
     */
    public void add(String methodName,ArrayList<String> types){
        methods.put(methodName,types);


    }




}
