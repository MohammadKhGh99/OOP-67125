package parser;

public class Error extends Exception {





}
