package parser;

import java.util.ArrayList;
//import parser.CompilationEngine;

public class Scope {

    private ArrayList<Variable> varsLst;
    public Scope parentScope;
    public int numscope;

    public Scope getParentScope() {
        return parentScope;
    }

    public Scope(int numscope, Scope parent){
        varsLst = new ArrayList<>();
        this.numscope = numscope;
        this.parentScope = parent;

    }


    /**
     * check contains
     * @param name
     * @return
     */
    public boolean contains(String name){
        Scope cur = this;
        if(cur.varsLst.size() == 0){
            return false;
        }
        while (cur != null) {
            for (Variable var : cur.varsLst) {
                if (var.getName().equals(name)) {
                    return true;
                }
            }
            cur = cur.parentScope;
        }
        return false;
    }


    /**
     * get the typ by var name
     * @param varName
     * @return
     */
    protected String typByName(String varName){
        Scope cur = this;
        while (cur != null) {
            for (Variable var : cur.varsLst) {
                if (var.getName().equals(varName)) {
                    return var.typ;
                }
            }
            cur = cur.parentScope;
        }
        return null;
    }


    /**
     * get the value by var name
     * @param varName
     * @return
     */
    protected String valueByName(String varName){
        Scope cur = this;
        while (cur != null) {
            for (Variable var : cur.varsLst) {
                if (var.getName().equals(varName)) {
                    return var.val;
                }
            }
            cur = cur.parentScope;
        }
        return null;
    }


    /**
     * by this method we will get the Variable obj which fit the given varname
     * @param varName the name of the var that we search
     * @return the variable which matches to the given name if we found it
     */
    public Variable getVariable(String varName){
        Scope cur = this;
        while (cur != null) {
            for (Variable var : cur.varsLst) {
                if (var.getName().equals(varName)) {
                    return var;
                }
            }
            cur = cur.parentScope;
        }
        return null;
    }


    /**
     *check if it's final
     * @param varName the var name that we want to check
     * @return a boolean value which tells us if the var isfinal or not
     */
    protected boolean isFinal(String varName){
        Scope cur = this;
        while (cur != null) {
            for (Variable var : cur.varsLst) {
                if (var.getName().equals(varName) && var.isFinal) {
                    return true;
                }
            }
            cur = cur.parentScope;
        }
        return false;
    }


    /**
     * by this method we can know if the var is a param for a method or not
     * @param varName the var that we want to check
     * @return a boolean value which tells us if the var isparam or not
     */
    protected boolean isParam(String varName){
        Scope cur = this;
        while (cur != null) {
            for (Variable var : cur.varsLst) {
                if (var.getName().equals(varName) && var.isParam) {
                    return true;
                }
            }
            cur = cur.parentScope;
        }
        return false;
    }


    /**
     * by this method we add the var to the varLst
     * @param name the name of var
     * @param typ typ of var
     * @param val val of var
     * @param isFinal var is final?
     * @param init var is init?
     * @param isParam var is param?
     */
    protected void addVar(String name, String typ, String val, boolean isFinal, boolean init,boolean isParam){
        varsLst.add(new Variable(name,typ,isFinal,val,init,isParam));
    }


    /**
     *
     * @return the var lst
     */
    protected ArrayList<Variable> getVarsLst(){
        return varsLst;
    }






}
