package parser;



public class Variable {

    public String name,typ,val;
    public boolean isFinal,initialized,isParam;


    public Variable(String name, String typ, String val){
        this.name = name;
        this.typ = typ;
        this.val = val;
    }

    public Variable(String name,String typ,boolean isFinal,String val,boolean initialized,boolean isParam){
        this.name = name;
        this.typ = typ;
        this.val = val;
        this.isFinal = isFinal;
        this.initialized = initialized;
        this.isParam = isParam;
    }


    protected boolean isFinal(){
        return isFinal;

    }

    protected boolean isParam(){
        return isParam;
    }

    public String getName(){
        return name;
    }

    public String getTyp(){
        return typ;
    }

    public String getVal(){
        return val;
    }




}
