package parser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import parser.CompilationEngine.*;

abstract public class SendLine implements Regex {


    private static final String EMPTY = "";
    protected static HashMap<Integer, ArrayList<Variable>> scopeVars = new HashMap<>();
    static int curDepth = 0;
    static Scope curScope;


    /**
     * by this method we will take each line and we will check if it's a legal line or not
     *
     * @param lines the lines of the file
     * @return a boolean value that tells us if there is a problem in the compilation processs or not
     */
    static public boolean isValid(ArrayList<String> lines) throws Error {
        curScope = new Scope(curDepth, null);
        for (String line : lines) {
            //the matches that we could get
            Matcher m0 = final_var_dec.matcher(line);
            Matcher m1 = assign.matcher(line);
            Matcher m2 = no_assign.matcher(line);
            Matcher m3 = varDec.matcher(line);
            Matcher m4 = comment.matcher(line);
            Matcher m5 = ifRegex.matcher(line);
            Matcher m6 = exitB.matcher(line);
            Matcher m7 = whileRegex.matcher(line);
            Matcher m8 = retuurnRegex.matcher(line);
            Matcher m9 = methodCall.matcher(line);
            Matcher m10 = methodDef.matcher(line);
            Matcher m11 = complexDec.matcher(line);



            //check the appropriate one
            if (m4.matches() || line.equals(EMPTY)) {
            } else if (m0.matches()) {
                if (CompilationEngine.compileFinal(line, m0, curScope)) {
                }
            } else if (m1.matches()) {
                if (CompilationEngine.compileVarAssign(line, m1, curScope)) {
                }
            } else if (m2.matches()) {
                CompilationEngine.compileInit(line, m2, curScope);
            } else if (m3.matches()) {
                CompilationEngine.compileVarDec(line, m3, curScope);
            } else if (m5.matches()) {
                CompilationEngine.compileIfWhile(line, m5, curScope);
                curDepth++;
                curScope = new Scope(curDepth, curScope);
            } else if (m6.matches()) { // }
                curScope = curScope.getParentScope();
                curDepth--;
                if(curDepth < 0){
                    throw new Error();
                }
            } else if (m7.matches()) {
                CompilationEngine.compileIfWhile(line, m7, curScope);
                curDepth++;
                curScope = new Scope(curDepth, curScope);
            } else if (m8.matches()) {
                checkLegalScope();
            } else if (m9.matches()) {
                CompilationEngine.compileMethodCall(line, m9, curScope);
            } else if (m10.matches()) {
                CompilationEngine.compileMethodDef(line, m10, curScope);
                curDepth++;
                curScope = new Scope(curDepth, curScope);
            } else if (m11.matches()) {
                if (CompilationEngine.compileComplexDec(line, m11, curScope, m0, m2, m3)) {
                    checkLegalScope();
                    return true;
                }
            } else {
                throw new Error();
            }
        }

        //in order to know if for each ({) there is a (}),because we add 1 when {,and decreas 1 when }
        if(curDepth != 0){
            throw new Error();
        }
        return true;
    }

    public static void clearData() {
        scopeVars = new HashMap<>();
        curDepth = 0;
        curScope = null;
    }


    private static void checkLegalScope() throws Error{
        if(curDepth != 1){
            throw new Error();
        }

    }


}
