package main;

import java.io.*;
import java.lang.*;
import java.util.ArrayList;
import java.util.HashMap;

import parser.CompilationEngine;
import parser.Error;
import parser.SendLine;

public class Sjavac {


    public final static int LEGAL = 0;
    public final static int ILLEGAL = 1;
    public final static int IO_ERROR = 2;


    /**
     * by this method we will real the file line by line then we will add each line to our lst
     *
     * @param filepath the file that we want to check
     * @return an arraylist thatcontains all the lines of the file
     * @throws IOError     the errror that we will throw
     * @throws IOException the error that we will throw
     */
    public static ArrayList<String> ReadFile(String filepath) throws IOError, IOException {
        ArrayList<String> lines = new ArrayList<>();
        Reader inFile = new FileReader(filepath);
        BufferedReader inBuffer = new BufferedReader(inFile);

        String line;
        while ((line = inBuffer.readLine()) != null) {
            lines.add(line);
        }
        return lines;
    }


    /**
     * here we will print the msg that will tell us if the file is a legal file or not
     *
     * @param args
     */
    public static void main(String args[]) {
        try {

            ArrayList<String> lines = ReadFile(args[0]);
            SendLine.isValid(lines);

            System.out.println(LEGAL);
        } catch (Error e) {
            System.out.println(ILLEGAL);
        } catch (IOException e) {
            System.out.println(IO_ERROR);
        }
        clearData();
//        try {
//            ArrayList<String> lines = ReadFile(args[0]);
//            for (String line : lines) {
//                SendLine.isValid(lines);
//            }
//            System.out.println(LEGAL);
//        } catch (oop.ex6.main.Error e) {
//            System.err.println(ILLEGAL);
//        }
//        catch (IOException e){
//            System.out.println(IO_ERROR);
//        }
    }

    private static void clearData() {
        CompilationEngine.clearData();
        SendLine.clearData();
    }
}
