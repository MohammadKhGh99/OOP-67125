package filesprocessing;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;

public class Parsing {


    private LinkedList<Section> sectionsList;
    private String commandPath;
    private String sourcePath;


    public Parsing(String sourcePath, String commandPath) {
        this.commandPath = commandPath;
        this.sourcePath = sourcePath;
        this.sectionsList = new LinkedList<>();
    }

    public LinkedList<Section> parsingFile() {
        try {
            List<String> allLine = Files.readAllLines(Paths.get(commandPath));
            if (allLine.size()<3){
                throw new SectionException("ERROR: FILTER or ORDER words missing (type II) \n");
            }
            int i = 0;
            while (i < allLine.size()-3) {
                if (!allLine.get(i).equals("FILTER") || !allLine.get(i+2).equals("ORDER")) {
                    throw new SectionException("ERROR: FILTER or ORDER words missing (type II) \n");
                }else {
                    String filterLine = allLine.get(i + 1);
                    int orderLineNumber = allLine.subList(i, allLine.size()).indexOf("ORDER") + 1;
                    String orderLine = allLine.get(orderLineNumber);
                    Section section = new Section();
                    Filter filter = FilterFactory.makingOneFilter(filterLine, i + 2, section);
                    File sourceFile = new File(sourcePath);
                    File[] filesArray = sourceFile.listFiles();
                    if (filesArray != null) {
                        for (File file : filesArray) {
                            if (filter.isPass(file)) {
                                section.files.add(file);
                            }
                        }
                    }
                    Order order = OrderFactory.makingOneOrder(orderLine, section.files, orderLineNumber, section);
                    order.sortFiles();
                    this.sectionsList.add(section);
                    i += allLine.indexOf(orderLine) + 1;
                }
            }
        } catch (IOException e) {
            System.err.println("ERROR: error in accessing to command file or the source file (type II) \n");

//            System.exit(-1);
        }catch (SectionException e){
            e.print();
//            System.exit(-1);
        }
        return this.sectionsList;
    }
}
