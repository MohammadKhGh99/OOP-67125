package filesprocessing;

import java.io.File;

public class SmallerThanFilter extends Filter {

    private double value;

    public SmallerThanFilter(double value) {
        this.value = value;
    }

    public SmallerThanFilter(double value, String not) {
        this.value = value;
        this.not = not;
    }

    @Override
    public boolean isPass(File file) {
        if (this.not.equals(NOT)) {
            return !((file.length() / BYTES_2_KBYTES) < this.value);
        }
        return (file.length() / BYTES_2_KBYTES) < this.value;
    }
}
