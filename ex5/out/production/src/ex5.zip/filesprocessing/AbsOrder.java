package filesprocessing;

import java.io.File;
import java.util.LinkedList;

public class AbsOrder extends Order {

    public AbsOrder(LinkedList<File> filteredFiles){
        this.filteredFiles=filteredFiles;
    }
    public AbsOrder(LinkedList<File> filteredFiles,String reverse){
        this.filteredFiles=filteredFiles;
        this.reverse=reverse;
    }
    @Override
    public void sortFiles() {
        for (int i = 0; i < filteredFiles.size() - 1; i++) {
            for (int j = i + 1; j < filteredFiles.size(); j++) {
                String absolute1 = filteredFiles.get(i).getAbsolutePath();
                String absolute2 = filteredFiles.get(j).getAbsolutePath();
                if (reverse.equals(REVERSE) && absolute1.compareTo(absolute2) > 0) {
                    File temp = filteredFiles.get(i);
                    filteredFiles.set(i,filteredFiles.get(j));
                    filteredFiles.set(j,temp);
                } else if (!reverse.equals(REVERSE) && absolute1.compareTo(absolute2) > 0) {
                    File temp = filteredFiles.get(i);
                    filteredFiles.set(i,filteredFiles.get(j));
                    filteredFiles.set(j,temp);
                }
            }
        }
    }
}
