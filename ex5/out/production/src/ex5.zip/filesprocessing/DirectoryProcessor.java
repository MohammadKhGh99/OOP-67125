package filesprocessing;

import java.io.File;
import java.util.LinkedList;

public class DirectoryProcessor {

    public static void main(String[] args){
        try {
            if (args.length>2){
                throw new BadParametersException("ERROR: more than two parameters in the configuration " +
                        "(type II error) \n");
            }
            Parsing parse = new Parsing(args[0], args[1]);
            LinkedList<Section> list=parse.parsingFile();
            for (Section section:list){
                for (String warning:section.warnings){
                    System.err.println(warning);
                }
                for (File file:section.files){
                    System.err.println(file.getName());
                }
            }
        }catch (BadParametersException e){
//            e.printStackTrace();
            e.print();
//            return;
//            System.exit(-1);
        }
    }
}
