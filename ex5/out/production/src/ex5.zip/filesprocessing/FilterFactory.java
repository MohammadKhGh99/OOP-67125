package filesprocessing;

public class FilterFactory {

    private static final String GREATER = "greater_than", BETWEEN = "between", SMALLER = "smaller_than", FILE = "file",
            CONTAINS = "contains", PREFIX = "prefix", SUFFIX = "suffix", WRITABLE = "writable",
            EXECUTABLE = "executable", HIDDEN = "hidden", ALL = "all", SEPARATOR = "#", YES = "YES", NO = "NO",
            FILTER = "FILTER", ORDER = "ORDER";

    /**
     * this method make one filter by the line that under the FILTER word.
     *
     * @param filterLine the filter line that is under the FILTER word.
     * @param numLine    the number of the current line.
     * @param section    the current section.
     * @return one type of filter.
     */
    public static Filter makingOneFilter(String filterLine, int numLine, Section section) {
        if (!filterLine.equals(FILTER) && !filterLine.equals(ORDER)) {
            String[] filterDesc = filterLine.split(SEPARATOR);
            String filter = filterDesc[0];
            try {
                switch (filter) {
                    case GREATER: {
                        double value = Double.parseDouble(filterDesc[1]);
                        if (value < 0) {
                            throw new BadParametersException("");
                        }
                        if (filterDesc.length == 3) {
                            String suffix = filterDesc[2];
                            return new GreaterThanFilter(value, suffix);
                        }
                        return new GreaterThanFilter(value);

                    }
                    case BETWEEN:
                        double first = Double.parseDouble(filterDesc[1]);
                        double second = Double.parseDouble(filterDesc[2]);
                        if (first < 0 || second < 0 || first > second) {
                            throw new BadParametersException("");
                        }
                        if (filterDesc.length == 4) {
                            String suffix = filterDesc[3];
                            return new BetweenFilter(first, second, suffix);
                        }
                        return new BetweenFilter(first, second);

                    case SMALLER: {
                        double value = Double.parseDouble(filterDesc[1]);
                        if (value < 0) {
                            throw new BadParametersException("");
                        }
                        if (filterDesc.length == 3) {
                            String suffix = filterDesc[2];
                            return new SmallerThanFilter(value, suffix);
                        }
                        return new SmallerThanFilter(value);

                    }
                    case FILE:
                        String filename = filterDesc[1];
                        if (filterDesc.length == 3) {
                            String suffix = filterDesc[2];
                            return new FileFilter(filename, suffix);
                        }
                        return new FileFilter(filename);

                    case CONTAINS:
                        String text = filterDesc[1];
                        if (filterDesc.length == 3) {
                            String suffix = filterDesc[2];
                            return new ContainsFilter(text, suffix);
                        }
                        return new ContainsFilter(text);

                    case PREFIX:
                        String prefix = filterDesc[1];
                        if (filterDesc.length == 3) {
                            String suffix = filterDesc[2];
                            return new PrefixFilter(prefix, suffix);
                        }
                        return new PrefixFilter(prefix);

                    case SUFFIX:
                        String suffix = filterDesc[1];
                        if (filterDesc.length == 3) {
                            String s = filterDesc[2];
                            return new SuffixFilter(suffix, s);
                        }
                        return new SuffixFilter(suffix);

                    case WRITABLE: {
                        String permission = filterDesc[1];
                        if (!permission.equals(YES) && !permission.equals(NO)) {
                            throw new BadParametersException("");
                        }
                        if (filterDesc.length == 3) {
                            String s = filterDesc[2];
                            return new WritableFilter(permission, s);
                        }
                        return new WritableFilter(permission);

                    }
                    case EXECUTABLE: {
                        String permission = filterDesc[1];
                        if (!permission.equals(YES) && !permission.equals(NO)) {
                            throw new BadParametersException("");
                        }
                        if (filterDesc.length == 3) {
                            String s = filterDesc[2];
                            return new ExecutableFilter(permission, s);
                        }
                        return new ExecutableFilter(permission);

                    }
                    case HIDDEN:
                        String hidden = filterDesc[1];
                        if (!hidden.equals(YES) && !hidden.equals(NO)) {
                            throw new BadParametersException("");
                        }
                        if (filterDesc.length == 3) {
                            String s = filterDesc[2];
                            return new HiddenFilter(hidden, s);
                        }
                        return new HiddenFilter(hidden);

                    case ALL:
                        if (filterDesc.length == 2) {
                            String s = filterDesc[1];
                            return new AllFilter(s);
                        }
                        return new AllFilter();
                }
            } catch (BadParametersException e) {
                section.warnings.add("Warning in line " + numLine);
                return new AllFilter();
            }
        }
        section.warnings.add("Warning in line " + numLine);
        return new AllFilter();

    }
}
