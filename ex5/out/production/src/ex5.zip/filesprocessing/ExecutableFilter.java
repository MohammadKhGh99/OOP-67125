package filesprocessing;

import java.io.File;

public class ExecutableFilter extends Filter{

    private String permission;

    public ExecutableFilter(String permission){
        this.permission=permission;
    }

    public ExecutableFilter(String permission,String not){
        this.permission=permission;
        this.not=not;
    }

    @Override
    public boolean isPass(File file) {
        if (this.permission.equals(YES)){
            if (this.not.equals(NOT)){
                return !file.canExecute();
            }
            return file.canExecute();
        }else {
            if (this.not.equals(NOT)){
                return file.canExecute();
            }
            return !file.canExecute();
        }
    }
}
