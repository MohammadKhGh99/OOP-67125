package filesprocessing;

import java.io.File;

abstract class Filter {

    protected  String not="";
    protected final String NOT="NOT";
    protected final double BYTES_2_KBYTES = 1024;
    protected final String YES = "YES";
    protected String NO="NO";
    protected final String PERIOD=".";

    abstract boolean isPass(File file);
}

