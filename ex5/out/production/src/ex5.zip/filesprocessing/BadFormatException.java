package filesprocessing;

public class BadFormatException extends HelperException {

    private String message;

    public BadFormatException(String message){
        this.message=message;
    }

    public void print(){
        System.err.println(this.message);
    }
}
