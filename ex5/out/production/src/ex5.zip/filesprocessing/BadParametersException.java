package filesprocessing;

public class BadParametersException extends Exception {


    private String message;

    public BadParametersException(String message){
        this.message=message;
    }

    public void print(){
        System.err.println(this.message);
    }

}
