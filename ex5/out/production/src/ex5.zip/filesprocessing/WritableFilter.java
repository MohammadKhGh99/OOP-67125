package filesprocessing;

import java.io.File;

public class WritableFilter extends Filter {

    private String permission;

    public WritableFilter(String permission) {
        this.permission = permission;
    }

    public WritableFilter(String permission, String not) {
        this.permission = permission;
        this.not = not;
    }

    @Override
    public boolean isPass(File file) {
        if (this.permission.equals(YES)) {
            if (this.not.equals(NOT)) {
                return !file.canWrite();
            }
            return file.canWrite();
        } else {
            if (this.not.equals(NOT)) {
                return file.canWrite();
            }
            return !file.canWrite();
        }
    }
}
