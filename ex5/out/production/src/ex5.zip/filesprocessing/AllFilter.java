package filesprocessing;

import java.io.File;

public class AllFilter extends Filter{

    public AllFilter(){

    }

    public AllFilter(String not){
        this.not=not;
    }

    @Override
    public boolean isPass(File file){
        return !this.not.equals(NOT);
    }
}
