package filesprocessing;

import java.io.File;
import java.util.LinkedList;

public class TypeOrder extends Order {

    public TypeOrder(LinkedList<File> filteredFiles) {
        this.filteredFiles = filteredFiles;
    }

    public TypeOrder(LinkedList<File> filteredFiles, String reverse) {
        this.filteredFiles = filteredFiles;
        this.reverse = reverse;
    }

    @Override
    public void sortFiles() {
        for (int i = 0; i < filteredFiles.size() - 1; i++) {
            for (int j = i + 1; j < filteredFiles.size(); j++) {
                int index1 = filteredFiles.get(i).getName().lastIndexOf(PERIOD);
                int index2 = filteredFiles.get(j).getName().lastIndexOf(PERIOD);
                String extension1 = "";
                String extension2 = "";
                if (index1 > -1 && index1 + 1 < filteredFiles.size()) {
                    extension1 = filteredFiles.get(i).getName().substring(index1 + 1);
                }
                if (index2 > -1 && index2 + 1 < filteredFiles.size()) {
                    extension2 = filteredFiles.get(j).getName().substring(index2 + 1);
                }
                if (extension1.equals(extension2)) {
                    twoEquals(i, j);
                } else if (this.reverse.equals(REVERSE) && extension1.compareTo(extension2) > 0) {
                    File temp = filteredFiles.get(i);
                    filteredFiles.add(i, filteredFiles.get(j));
                    filteredFiles.add(j, temp);
                } else if (!this.reverse.equals(REVERSE) && extension1.compareTo(extension2) < 0) {
                    File temp = filteredFiles.get(i);
                    filteredFiles.add(i, filteredFiles.get(j));
                    filteredFiles.add(j, temp);
                }
            }
        }
    }
}
