package filesprocessing;

import java.io.File;

public class FileFilter extends Filter {

    private String filename;

    public FileFilter(String filename) {
        this.filename = filename;
    }

    public FileFilter(String filename, String not) {
        this.filename = filename;
        this.not = not;
    }

    @Override
    public boolean isPass(File file) {
        if (this.not.equals(NOT)) {
            return !file.getName().equals(this.filename);
        }
        return file.getName().equals(this.filename);
    }
}
