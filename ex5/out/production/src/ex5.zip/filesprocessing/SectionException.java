package filesprocessing;

public class SectionException extends HelperException{

    private String message;

    public SectionException(String message){
        this.message=message;
    }

    public void print(){
        System.err.println(this.message);
    }
}
