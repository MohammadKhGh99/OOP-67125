package filesprocessing;

import java.io.File;

public class HiddenFilter extends Filter {

    private String hidden;

    public HiddenFilter(String hidden) {
        this.hidden = hidden;
    }

    public HiddenFilter(String hidden, String not) {
        this.hidden = hidden;
        this.not = not;
    }

    @Override
    public boolean isPass(File file) {
        if (this.hidden.equals(YES)) {
            if (this.not.equals(NOT)) {
                return !file.isHidden();
            }
            return file.isHidden();
        } else {
            if (this.not.equals(NOT)) {
                return file.isHidden();
            }
            return !file.isHidden();
        }
    }
}
