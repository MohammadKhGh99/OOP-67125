package filesprocessing;

import java.io.File;
import java.util.LinkedList;

public class SizeOrder extends Order {

    public SizeOrder(LinkedList<File> filteredFiles) {
        this.filteredFiles = filteredFiles;
    }

    public SizeOrder(LinkedList<File> filteredFiles, String reverse) {
        this.filteredFiles = filteredFiles;
        this.reverse = reverse;
    }

    @Override
    public void sortFiles() {
        for (int i = 0; i < filteredFiles.size() - 1; i++) {
            for (int j = i + 1; j < filteredFiles.size(); j++) {
                Long size1 = filteredFiles.get(i).length();
                Long size2 = filteredFiles.get(j).length();
                if (size1 == size2) {
                    twoEquals(i, j);
                }
                if (this.reverse.equals(REVERSE) && size1 > size2) {
                    File temp = filteredFiles.get(i);
                    filteredFiles.add(i, filteredFiles.get(j));
                    filteredFiles.add(j, temp);
                } else if (!this.reverse.equals(REVERSE) && size1 < size2) {
                    File temp = filteredFiles.get(i);
                    filteredFiles.add(i, filteredFiles.get(j));
                    filteredFiles.add(j, temp);
                }
            }
        }
    }
}
