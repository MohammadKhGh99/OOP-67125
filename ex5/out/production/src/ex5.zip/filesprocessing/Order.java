package filesprocessing;

import java.io.File;
import java.util.LinkedList;

public abstract class Order {

    protected String reverse = "";
    protected final String REVERSE = "REVERSE";
    protected LinkedList<File> filteredFiles;
    protected final String PERIOD = ".";

    public abstract void sortFiles();

    public void twoEquals(int i, int j) {
        LinkedList<File> array = new LinkedList<>();
        array.add(filteredFiles.get(i));
        array.add(filteredFiles.get(j));
        new AbsOrder(array).sortFiles();
    }
}

