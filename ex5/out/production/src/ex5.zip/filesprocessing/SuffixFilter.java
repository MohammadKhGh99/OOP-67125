package filesprocessing;

import java.io.File;

public class SuffixFilter extends Filter {

    private String suffix;

    public SuffixFilter(String suffix) {
        this.suffix = suffix;
    }

    public SuffixFilter(String suffix, String not) {
        this.suffix = suffix;
        this.not = not;
    }

    @Override
    public boolean isPass(File file) {
        if (this.suffix.equals(PERIOD) && !file.getName().contains(PERIOD)) {
            return true;
        }
        if (this.not.equals(NOT)) {
            return !file.getName().endsWith(this.suffix);
        }
        return file.getName().endsWith(this.suffix);
    }
}
