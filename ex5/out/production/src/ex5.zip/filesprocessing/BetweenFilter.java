package filesprocessing;

import java.io.File;

public class BetweenFilter extends Filter {

    private double first;

    private double second;

    public BetweenFilter(double first,double second){
        this.first=first;
        this.second=second;
    }

    public BetweenFilter(double first,double second,String not){
        this.first=first;
        this.second=second;
        this.not=not;
    }

    @Override
    public boolean isPass(File file) {
        if (this.not.equals(NOT)){
            return !((file.length()/BYTES_2_KBYTES)>=this.first && (file.length()/BYTES_2_KBYTES)<=this.second);
        }
        return (file.length()/BYTES_2_KBYTES)>=this.first && (file.length()/BYTES_2_KBYTES)<=this.second;
    }
}
