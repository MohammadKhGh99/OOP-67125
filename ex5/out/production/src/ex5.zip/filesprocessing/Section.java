package filesprocessing;

import java.io.File;
import java.util.LinkedList;

public class Section {

    public LinkedList<String> warnings;
    public LinkedList<File> files;

    public Section() {
        this.warnings = new LinkedList<>();
        this.files = new LinkedList<>();
    }
}
