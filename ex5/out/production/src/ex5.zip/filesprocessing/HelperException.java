package filesprocessing;

public class HelperException extends Exception {
}
