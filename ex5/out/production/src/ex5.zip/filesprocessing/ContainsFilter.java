package filesprocessing;

import java.io.File;

public class ContainsFilter extends Filter {

    private String text;

    public ContainsFilter(String text) {
        this.text = text;
        this.not = "";
    }

    public ContainsFilter(String text, String not) {
        this.text = text;
        this.not = not;
    }

    @Override
    public boolean isPass(File file) {
        int i = file.getName().lastIndexOf(PERIOD);
        if (i > -1) {
            if (this.not.equals(NOT)) {
                return !file.getName().substring(0, i).contains(this.text);
            }
            return file.getName().substring(0, i).contains(this.text);

        } else {
            if (this.not.equals(NOT)){
                return !file.getName().contains(this.text);
            }
            return file.getName().contains(this.text);
        }
    }
//    public static void main(String[] args){
//        ContainsFilter cf=new ContainsFilter("tx");
//        File file=new File("D:\\.IntelliJIdea2018.3\\OOP\\ex5\\src\\filesprocessing\\txextx.txt");
//        File file=new File("D:\\.IntelliJIdea2018.3\\OOP\\ex4\\src\\README");
//        System.out.println(cf.isPass(file));
//        String s="file#file.txt#NOT";
//        String[] x=s.split("#");
//        for (String a:x) {
//            System.out.println(a);
//        }
//    }
}
