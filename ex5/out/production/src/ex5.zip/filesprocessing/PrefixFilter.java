package filesprocessing;

import java.io.File;

public class PrefixFilter extends Filter {

    private String prefix;

    public PrefixFilter(String prefix) {
        this.prefix = prefix;
    }

    public PrefixFilter(String prefix, String not) {
        this.prefix = prefix;
        this.not = not;
    }

    @Override
    public boolean isPass(File file) {
        if (this.not.equals(NOT)) {
            return !(file.getName().startsWith(this.prefix));
        }
        return file.getName().startsWith(this.prefix);
    }
}
